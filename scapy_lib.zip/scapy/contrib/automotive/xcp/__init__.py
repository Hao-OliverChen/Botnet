# This file is part of Scapy
# See http://www.secdev.org/projects/scapy for more information
# Copyright (C) Tabea Spahn <tabea.spahn@e-mundo.de>
# This program is published under a GPLv2 license

# scapy.contrib.status = skip

"""
Package of contrib automotive xcp specific modules
that have to be loaded explicitly.
"""
